#ifndef _ACTIVDECLSDEFINED
#define _ACTIVDECLSDEFINED
/*
ActivBoard USB ControlBytes (BYTE[1] in the packet read from the board)
*/
typedef int CALIBRATION_MODE;
typedef enum
{
    // MOUSE
    CB_COORD_PEN1			= 0x21,
    CB_COORD_PEN2			= 0x22,

    CB_FIRMWARE_PACKET      = 0x33,
    CB_PRESSURE_AC3         = 0xA1, // fake, used internally
    // Instead of sending negative coords, the ac3 uses a proper tag.
    // direct connection only sends the control byte,
    // RF version also sends the serial number of the board.
    CB_AC3_REQUEST_CALIB    = 0x34,
    CB_FOLIO_FX_START       = 0x35,
    CB_FOLIO_FX_STATUS      = 0x36,
    CB_FOLIO_FX_END         = 0x37,
    CB_FOLIO_FX_VERSIONS    = 0x38,

    // VOTE
    CB_RF_VOTE_RESP			= 0x65,
    CB_RF_VOTE_REG_RESP		= 0x67,
    CB_RF_VOTE_TYPE			= 0x68,

    // SLATE
    CB_RF_PIC_SLATE_COORD	= 0x01,
    CB_RF_PIC_SLATE_REG		= 0x07,
    CB_RF_PIC_SLATE_PIN		= 0x07,
    CB_RF_SLATE_END_VOTE	= 0x68,
    CB_RF_REQ_MODE_BOX		= 0x04,

    // GENERAL
    CB_TEST_REC_BOUNCE		= 0x70,
    CB_RF_VERSION			= 0x66,
    CB_RF_LISTEN_CONFIRM	= 0x6A,
    CB_REG_CONFIRM			= 0x68,
    CB_SELFTEST				= 0x2E,
    CB_RSSI					= 0x68,
    CB_BIT_ERROR			= 0x68,
    CB_RF_BOARD_ID			= 0x69,
    CB_2_4_GENERAL			= 0x77,
    CB_RF_STRING_ACK		= 0x68,
    CB_PEN_STATE			= 0x31,
    CB_GENERAL				= 0x32,

    // 2.4
    CB_2_4_DEVICE_COUNT			= 0x40, // int
    CB_2_4_DEVICES_INFO         = 0x51,
    CB_2_4_EXT_REG_RESP			= 0x80, // same as 0x67, but with more data. Used for expressions and AC3 boards
    CB_2_4_EXPRESSION_STRING_RESPONSE = 0x83,
    CB_2_4_EXPRESSION_ASYNC_DEVICE_REQUEST = 0x84,
    CB_2_4_EXPRESSION_ASYNC_DATA_REQUEST = 0x85,
    CB_2_4_VOTE_TEST			= 0x0e,

    CB_ECHO_PACKET              = 0x41,
    CB_STATE_PACKET             = 0x42, // driver state, so far, only voting state
    CB_GESTURE_PACKET           = 0x43,
    CB_PROXIMITY_PACKET         = 0x44,
    CB_AC4_COORD_DATA           = 0x45,
    CB_POWER_MESSAGE            = 0x50,
    CB_INTF_VERSION				= 0x52, // firmware interface version
    CB_DEVICE_TYPE_COUNT        = 0x53,
    CB_AC3_EXT_COORD            = 0x54,
    CB_AC3_PEN_STATE            = 0x55,
    CB_2_4_RF_CHANGE_STATE      = 0x56,

    CB_AC3_REGISTRATION         = 0x90,
    CB_USB_GENERAL_BOARD_MSG    = 0x91,
    CB_REMOTE_DEVICE            = 0xb0,
    CB_REMOTE_KEY               = 0xb1,

    CB_REENUMERATE				= 0xA0,
    CB_SET_PEN_STATES			= 0xA1,
    CB_PEN_TEST					= 0xA2,
    CB_VIRTUAL_NAME				= 0xA3,
    CB_AC4_SYSTEM_COORD_DATA	= 0xA7,
    CB_AC_COORD_REDIRECT_PEN    = 0xA8,
    CB_AC_COORD_REDIRECT_TOUCH  = 0xA9,
	
	// Third-party specific
	CB_PEN_COUNT				= 0x39,
	CB_TOUCH_COUNT				= 0x3A,
    CB_PICASSO_DATA_EX          = 0x3B,
    CB_PICASSO_PEN_PAIR_MODE    = 0x3C,
    CB_PICASSO_PEN_PAIR_COUNT   = 0x3D,
    CB_PEN_BATTERY_VOLTS        = 0x3E,
	CB_LARGE_TOUCH_COUNT		= 0x3F,
	CB_ADDITIONAL_INFO			= 0xC0
} USB_CONTROL_BYTES;

typedef enum
{
    // MOUSE
    CBS_COORD_PEN1     		= 0x1,
    CBS_COORD_PEN2			= 0x2,
    CBS_SLATE_VERSION		= 0x3,
    CBS_PANDA_CONTEXT		= 0x4,
    CBS_VOTING_INFO			= 0x5,
    CBS_PIC_VERSION			= 0x6,
    CBS_REG_INFO			= 0x7,
    CBS_ID_CONFIRM			= 0x8,
    CBS_RF_ID_TO_PC			= 0x9,
    CBS_OTHER_BOARDS		= 0xA,
    CBS_SELF_TEST	= 0xE,
    CBS_VECTOR				= 0xF,
    CBS_BOUNCE				= 0x10,
    CBS_EXTRA				= 0x11,
    CBS_PEN_STATE			= 0x11,
    CBS_PRESSURE1           = 0x13,
    CBS_PRESSURE2           = 0x14,
    CBS_INTF_VERSION        = 0x15,
    CBS_GENERAL				= 0x1f, // not actually sent by the board, faked by the driver.
    CBS_ECHO_PACKET         = 0x1e, // not actually sent by the board, faked by the driver.
    CBS_STATE_PACKET        = 0x1d, // not actually sent by the board, faked by the driver.
    CBS_GESTURE_PACKET      = 0x1c,
    CBS_PROXIMITY_PACKET    = 0x1b,
    CBS_RF_BOARD_ID			= 0x69,
    CBS_POWER_MESSAGE       = 0x50,
} SERIAL_CONTROL_BYTES;

typedef enum {
    DEST_OS,		// pen/slate coordinates sent to Windows mouse queue
    DEST_APP,		// pen/slate coordinate packets sent to application that requests it
    DEST_OS_APP,		// pen/slate sent to Windows and Application
    DEST_DISABLED,

    DEST_UNKNOWN = 0xff,
} PEN_OR_SLATE_DESTINATION;

typedef enum {
    FOLIO_FXSTATUS_ERROR = 0,
    FOLIO_FXSTATUS_READY = 1,
    FOLIO_FXSTATUS_RESTART_REQUIRED = 2,
    FOLIO_FXSTATUS_WAIT = 2
} FOLIO_FX_STATUS;


typedef struct _LastXYZ
{
    unsigned short x,y,z;
} LastXYZ;

typedef enum
{
    AVS_Unknown = 0,
    AVS_Idle = 1,
    AVS_DeviceRegistration,
    AVS_DevicePinRegistration,
    AVS_Voting,

    AVS_VotingSingleResponse,
    AVS_VotingMultipleResponse,
    AVS_TestSession,
    AVS_Device3CharPinRegistration,
    AVS_Device4CharPinRegistration,

    AVS_ServerEcho = 100,
    AVS_STATES
} ACTIVOTING_STATE;


/*
* 	Debug Levels.
*/
#if !defined(TRACE_LEVEL_NONE)
#define TRACE_LEVEL_NONE        0
#define TRACE_LEVEL_CRITICAL    1
#define TRACE_LEVEL_FATAL       1
#define TRACE_LEVEL_ERROR       2
#define TRACE_LEVEL_WARNING     3
#define TRACE_LEVEL_INFORMATION 4
#define TRACE_LEVEL_VERBOSE     5
#define TRACE_LEVEL_MEGAVERBOSE 6
#define TRACE_LEVEL_RESERVED7   7
#define TRACE_LEVEL_RESERVED8   8
#define TRACE_LEVEL_RESERVED9   9
#endif

// This is our own definition.
#define TRACE_LEVEL_RELEASE TRACE_LEVEL_CRITICAL

#define DRV_DBG_INIT            0x1
#define DRV_DBG_CONFIG          0x2
#define DRV_DBG_PNP             0x4
#define DRV_DBG_POWER           0x8
#define DRV_DBG_BOARD_DATA      0x10
#define DRV_DBG_USER_DATA       0x20
#define DRV_DBG_THREADS         0x40
#define DRV_DBG_DEBUG           0x80
#define DRV_DBG_DEBUG_EXTRA     0x100

// warnings are always release
#define DRV_DBG_WARNINGS (DRV_DBG_WARNING|DRV_DBG_RELEASE)


/* In linux, we can choose what the clients receive (unlike in windows where all HID clients receive all the data)
This mask is used to decide what a client receivs. The default is ACTIV_XFER_INFO */
enum {  ACTIV_XFER_COORDINATES  = 0x1,
        ACTIV_XFER_PRESSURE     = 0x2,
        ACTIV_XFER_INFO         = 0x4,

        /* NB When adding masked values, you must update the driver code for
ACTIV_SET_XFER_MASK: if only copies the bits defined in the enum, to avoid
people sending undefined values) */

        ACTIV_XFER_ALL          = 0xFF};

typedef enum
{
    CHANGE_BOARD_ID,
    CLEAR_DEVICES
} REENUMERATE_REASON;

#define MAX_ACTIV_BOARDS 4
#define MAX_ACTIV_PENS_PER_BOARD 16
#define MAX_ACTIV_ACTUAL_PENS_PER_BOARD 3
#define MAX_ACTIV_SLATES 32
#define MAX_ACTIV_FOLIO 64
#define MAX_ACTIV_TOUCHES_PER_BOARD 12

#define MAX_MOUSE_RANGE 0x7fff

#endif
