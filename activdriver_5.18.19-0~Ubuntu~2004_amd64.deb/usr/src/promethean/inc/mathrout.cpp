#ifdef _CLIENT_APP_

#include <windows.h>

#else
	#ifdef _WIN_DRIVER_
    extern "C"
    {
    #include <wdm.h>
    };

    #if DBG

    #else
    extern LONG DriverDebugMode;
    #endif
    #else
    #include <linux/wtypes.h>
	#endif
#endif

#include "mathrout.h"
#include "activcalibration.h"
#include <decls.h>

#include "calibrate_code.h"

/* -------------------------------------------------------------------------- */
int bboxclip(long *bbox, long *p)
{
	if (p[0] < bbox[0]||p[0] > bbox[2])
		return FALSE;
	if (p[1] < bbox[1]||p[1] > bbox[3])
		return FALSE;

	return TRUE;
}
/* -------------------------------------------------------------------------- */
int cvvclip(int r, long *p, long accy)
{
	// clip front and back projection limits.
	if (p[2] >= 0)
		return FALSE;
	if (((-1*powe(1,r)) - p[2]) > accy)
		return FALSE;

	// clip x against x = +/-z pyramid sides.
	if ((absol(p[0]) - absol(p[2])) > accy)
		return FALSE;


	// clip y against y = +/-z pyramid sides.
	if ((absol(p[1]) - absol(p[2])) > accy)
		return FALSE;

	return TRUE;
}
/* -------------------------------------------------------------------------- */
void cvvproject(int r, long *p)
{
	p[0]=IMulDiv32( p[0],powe(1,r), -p[2]);
	p[1]=IMulDiv32(p[1], powe(1,r), -p[2]);
}
/* -------------------------------------------------------------------------- */
void format(long *outrect,int rOutrect,int rNorm,long *out4,long *out)
{

// project by dividing through by z-component.
		cvvproject(rNorm, out4);
		// scale to desired output size.
		out[0] = convert(rOutrect, rNorm, out4[0]);
		out[1] = convert(rOutrect, rNorm, out4[1]);
		out[0] +=powe(1,rOutrect);
		out[1] +=powe(1,rOutrect);

		//X(out) = X(out) * (RIGHT(c->outrect) - LEFT(c->outrect)) / 2;
		//X(out) = IFIXCONV(0, c->rOutrect, X(out4));
		out[0]=IMulDiv32(out[0],outrect[2],powe(1,rOutrect));//c-> - c->outrect[0],powe(1,c->rOutrect))
		out[0] = round(1, out[0]);
		out[0]=65535*out[0];
		out[0]=out[0]/outrect[2];

		//Y(out) = Y(out) * (BOTTOM(c->outrect) - TOP(c->outrect)) / 2;
		//Y(out) = IFIXCONV(0, c->rOutrect, Y(out4));
		out[1]=IMulDiv32(out[1],outrect[3],powe(1,rOutrect));//c-> - c->outrect[1],powe(1,c->rOutrect));
		out[1] = round(1, out[1]);
		out[1]=65535*out[1];
		out[1]=out[1]/outrect[3];

	//	out[0] += c->outrect[0];
	//	out[1] += c->outrect[1];


}

void formatex(long *outrect,int rOutrect,int rNorm,
                long* wndrect,long* desktoprect,long *out4,long *out,
                BOOLEAN slate)
{
		if (slate)
		{
            int max_width, max_height;
		    max_width = 12000;
		    max_height = 8800;
			out[0] = out4[0];
			out[1] = max_height - out4[1];			// slate is reversed, and always 12000 to 8800

			// coords are in 12000 x 8800 range
			out[0] = IMulDiv32(out[0], wndrect[2]-wndrect[0], desktoprect[2]-desktoprect[0]);
			out[1] = IMulDiv32(out[1], wndrect[3]-wndrect[1], desktoprect[3]-desktoprect[1]);

        	out[0] = IMulDiv32(out[0], MAX_MOUSE_RANGE, max_width);
        	out[1] = IMulDiv32(out[1], MAX_MOUSE_RANGE, max_height);
		}
		else
		{
			// project by dividing through by z-component.
			cvvproject(rNorm, out4);

			// scale to desired output size.
			out[0] = convert(rOutrect, rNorm, out4[0]);
			out[1] = convert(rOutrect, rNorm, out4[1]);
			out[0] +=powe(1,rOutrect);
			out[1] +=powe(1,rOutrect);

			//X(out) = X(out) * (RIGHT(c->outrect) - LEFT(c->outrect)) / 2;
			//X(out) = IFIXCONV(0, c->rOutrect, X(out4));
			out[0]=IMulDiv32(out[0],outrect[2],powe(1,rOutrect));//65535,powe(1,rOutrect));
			out[0] = round(1, out[0]);
			out[0]=IMulDiv32(MAX_MOUSE_RANGE, out[0],desktoprect[2]-desktoprect[0]); // (W * O) / D

			//Y(out) = Y(out) * (BOTTOM(c->outrect) - TOP(c->outrect)) / 2;
			//Y(out) = IFIXCONV(0, c->rOutrect, Y(out4));
			out[1]=IMulDiv32(out[1],outrect[3],powe(1,rOutrect));//c->outrect[3] - c->outrect[1],powe(1,c->rOutrect));
			out[1] = round(1, out[1]);
			out[1] = IMulDiv32(MAX_MOUSE_RANGE, out[1], desktoprect[3]-desktoprect[1]);
		}
/*
		// offset is ratio of left side of rect to full desktop width
		offset_left = IMulDiv32(MAX_MOUSE_RANGE ,wndrect[0], desktoprect[2]);
		out[0]=offset_left +  out[0];


		offset_top = IMulDiv32(MAX_MOUSE_RANGE, wndrect[1],desktoprect[3]);
		out[1]=offset_top + out[1];
*/

	//	out[0] += c->outrect[0];
	//	out[1] += c->outrect[1];


}

/* -------------------------------------------------------------------------- */
long round(long r, long x)
{
	long tempA,tempB,tempC;

	if (r == 0)
		return(x);
	else if (x == 0)
		return(0);
	else if (x < 0)
	{
		tempA=(x/powe(1,r));
		tempB=(x%powe(1,r));
		tempC=powe(1,r);
		tempC=tempC/2;
		return(tempA-(tempB<tempC));

//		return(r/powe(1,r)) - (r%(powe(1,r))<(-powe(1,r)/2)));//(-0.5*powe(1,r))
	}
	else
	{
		tempA=(x/powe(1,r));
		tempB=(x%powe(1,r));
		tempC=(powe(1,r)/2);
		return(tempA+(tempB>=tempC));
//		return(1000);//(r/powe(1,r)) + (r%(powe(1,r))>=(powe(1,r)/2)));
	}
	// return(1);
}

/* -------------------------------------------------------------------------- */
long convert(long _nr, long _or, long x)
{
	long ifixconv;

	ifixconv =_nr - _or;
	if (ifixconv >= 0)
		return(x*powe(1,ifixconv));
	else
		return(round(-ifixconv, x));
}

/* -------------------------------------------------------------------------- */
void if4vectormul(int rO, long *vO, int rA, long mA[4][4], int rI, long *vI)
{
	int r;
	int i, j;


	r = rA + rI - rO;

	for (i  = 0; i < 4; i++)
	{
		vO[i] = 0;
		for (j  = 0; j < 4; j++)
		{
			long term;

			term=IMulDiv32(vI[j], mA[i][j],powe(1,r));
			vO[i] += term;
		}
	}
}

/* -------------------------------------------------------------------------- */
void ifhomogenize(int dim, int r, long *v)
{
	int i;

	for (i = 0; i < dim - 1; i++) {
		v[i]=IMulDiv32(v[i],powe(1,r),v[dim - 1]);
	}
	v[dim - 1] = powe(1,r);
}

/* -------------------------------------------------------------------------- */
long IMulDiv32(long aa, long ab, long ac)
{
	long	ia,ib,ic,ret;
	int	sign;


	if (aa == 0)
		return(0);
	if  (ab == 0)
		return(0);
	if (ac == 0)
		return(0);			
	if (ac == 1)
		return((int)(aa*ab));
	if (aa == 1)
		return((int)(ab/ac));
	if (ab == 1)
		return((int)(aa/ac));
	if (aa == ac)
		return(ab);
	if (ab == ac)
		return(aa);

	sign  = (aa < 0);
	ia = absol(aa);
	sign ^= (ab < 0);
	ib = absol(ab);
	sign ^= (ac < 0);
	ic = absol(ac);

	ret=scale(ia,ib,ic);

	if (sign == 1)
		ret = -ret;
	return ((int)ret);

}

long powe(long base,int power)
{
	return(base<<power);
}

long absol(long x)
{
	if(x<0)
		return(-x);
	return(x);
}

long scale(long a,long b,long c)
{
long a_hi,a_lo,b_hi,b_lo,res_hi,res_lo,res_temp;
int i;

a_hi=(a&0xffff0000)>>16;
b_hi=(b&0xffff0000)>>16;
a_lo=a&0x0000ffff;
b_lo=b&0x0000ffff;
res_hi=a_hi*b_hi;
res_lo=a_lo*b_lo;
res_temp=a_hi*b_lo;
res_hi+=(res_temp&0xffff0000)>>16;
res_lo+=(res_temp&0x0000ffff)<<16;
res_temp=a_lo*b_hi;
res_hi+=(res_temp&0xffff0000)>>16;
res_lo+=(res_temp&0x0000ffff)<<16;

a=0;
b=res_hi;
for(i=0;i<32;i++)
{
		a<<=1;
	b=(b<<1);//|(res_lo>LONG_MAX?1:0);
	if(res_lo&0x80000000)
		b|=1;
	while(b>=c)
	{
		b-=c;
		a++;
	}
	res_lo<<=1;
}
return(a);
}

