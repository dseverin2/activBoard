/* -------------------------- OutMathSupport.c --------------------------------- */
/*------------------------------------------------------------------------------
IFIX math routines.
------------------------------------------------------------------------------*/

#include "usbpromethean.h"

static unsigned short cosLUT[]={10000,9999,9999,9997,9996,9994,9991,9988,9985,9981,
                                9976,9971,9966,9960,9954,9947,9940,9932,9924,9916,
                                9907,9897,9887,9877,9866,9855,9843,9831,9818,9805,
                                9791,9777,9762,9747,9732,9716,9700,9683,9666,9648,
                                9630,9611,9592,9573,9553,9533,9512,9490,9469,9447,
                                9424,9401,9378,9354,9329,9305,9279,9254,9228,9201,
                                9174,9147,9119,9091,9063,9034,9004,8974,8944,8913,
                                8882,8851,8819,8786,8754,8720,8687,8653,8619,8584,
                                8549,8513,8477,8441,8404,8367,8329,8291,8253,8214,
                                8175,8136,8096,8056,8015,7974,7933,7891,7849,7807,
                                7764,7721,7677,7634,7589,7545,7500,7455,7409,7363,
                                7317,7270,7223,7176,7128,7080,7032,6983,6934,6885,
                                6835,6786,6735,6685,6634,6583,6531,6479,6427,6375,
                                6322,6269,6216,6163,6109,6055,6000,5946,5891,5835,
                                5780,5724,5668,5612,5555,5498,5441,5384,5326,5269,
                                5211,5152,5094,5035,4976,4917,4857,4797,4738,4677,
                                4617,4556,4496,4435,4373,4312,4250,4189,4127,4064,
                                4002,3939,3877,3814,3751,3687,3624,3560,3496,3433,
                                3368,3304,3240,3175,3110,3046,2981,2915,2850,2785,
                                2719,2653,2588,2522,2456,2390,2323,2257,2191,2124,
                                2057,1991,1924,1857,1790,1723,1655,1588,1521,1453,
                                1386,1318,1251,1183,1115,1047,980,912,844,776,708,
                                640,572,504,436,368,299,231,163,95,27,0,0,0,0,0,
                                0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

/* -------------------------------------------------------------------------- */
int bboxclip(long *bbox, long *p)
{
    if (p[0] < bbox[0]||p[0] > bbox[2])
        return FALSE;
    if (p[1] < bbox[1]||p[1] > bbox[3])
        return FALSE;

    return TRUE;
}
/* -------------------------------------------------------------------------- */
int cvvclip(int r, long *p, long accy)
{
    // clip front and back projection limits.
    if (p[2] >= 0)
        return FALSE;
    if (((-1*powe(1,r)) - p[2]) > accy)
        return FALSE;

    // clip x against x = +/-z pyramid sides.
    if ((absol(p[0]) - absol(p[2])) > accy)
        return FALSE;


    // clip y against y = +/-z pyramid sides.
    if ((absol(p[1]) - absol(p[2])) > accy)
        return FALSE;

    return TRUE;
}
/* -------------------------------------------------------------------------- */
void cvvproject(int r, long *p)
{
    p[0]=IMulDiv32( p[0],powe(1,r), -p[2]);
    p[1]=IMulDiv32(p[1], powe(1,r), -p[2]);
}
/* -------------------------------------------------------------------------- */
void format(long *outrect,int rOutrect,int rNorm,long *out4,long *out)
{

    // project by dividing through by z-component.
    cvvproject(rNorm, out4);
    // scale to desired output size.
    out[0] = convert(rOutrect, rNorm, out4[0]);
    out[1] = convert(rOutrect, rNorm, out4[1]);
    out[0] +=powe(1,rOutrect);
    out[1] +=powe(1,rOutrect);

    //X(out) = X(out) * (RIGHT(c->outrect) - LEFT(c->outrect)) / 2;
    //X(out) = IFIXCONV(0, c->rOutrect, X(out4));
    out[0]=IMulDiv32(out[0],outrect[2],powe(1,rOutrect));//c-> - c->outrect[0],powe(1,c->rOutrect))
    out[0] = round(1, out[0]);
    out[0]=65535*out[0];
    out[0]=out[0]/outrect[2];

    //Y(out) = Y(out) * (BOTTOM(c->outrect) - TOP(c->outrect)) / 2;
    //Y(out) = IFIXCONV(0, c->rOutrect, Y(out4));
    out[1]=IMulDiv32(out[1],outrect[3],powe(1,rOutrect));//c-> - c->outrect[1],powe(1,c->rOutrect));
    out[1] = round(1, out[1]);
    out[1]=65535*out[1];
    out[1]=out[1]/outrect[3];

    //	out[0] += c->outrect[0];
    //	out[1] += c->outrect[1];


}

void formatex(long *outrect,int rOutrect,int rNorm,
              long* wndrect,long* desktoprect,long *out4,long *out,
              unsigned char slate)
{

    if (slate)
    {
        int max_width, max_height;
        max_width = 12000;
        max_height = 8800;
        out[0] = out4[0];
        out[1] = max_height - out4[1];			// slate is reversed, and always 12000 to 8800

        // coords are in 12000 x 8800 range
        //out[0] = IMulDiv32(out[0], wndrect[2]-wndrect[0], desktoprect[2]-desktoprect[0]);
        //out[1] = IMulDiv32(out[1], wndrect[3]-wndrect[1], desktoprect[3]-desktoprect[1]);

        out[0] = IMulDiv32(out[0], MAX_MOUSE_RANGE, max_width);
        out[1] = IMulDiv32(out[1], MAX_MOUSE_RANGE, max_height);
    }
    else
    {
        // project by dividing through by z-component.
        cvvproject(rNorm, out4);

        // scale to desired output size.
        out[0] = convert(rOutrect, rNorm, out4[0]);
        out[1] = convert(rOutrect, rNorm, out4[1]);
        out[0] +=powe(1,rOutrect);
        out[1] +=powe(1,rOutrect);

        //X(out) = X(out) * (RIGHT(c->outrect) - LEFT(c->outrect)) / 2;
        //X(out) = IFIXCONV(0, c->rOutrect, X(out4));
        out[0]=IMulDiv32(out[0],outrect[2],powe(1,rOutrect));//65535,powe(1,rOutrect));
        out[0]=IMulDiv32(MAX_MOUSE_RANGE, out[0],outrect[2]); // (W * O) / D
        out[0] = round(1, out[0]);

        //Y(out) = Y(out) * (BOTTOM(c->outrect) - TOP(c->outrect)) / 2;
        //Y(out) = IFIXCONV(0, c->rOutrect, Y(out4));
        out[1]=IMulDiv32(out[1],outrect[3],powe(1,rOutrect));//c->outrect[3] - c->outrect[1],powe(1,c->rOutrect));
        out[1] = IMulDiv32(MAX_MOUSE_RANGE, out[1], outrect[3]);
        out[1] = round(1, out[1]);
    }
    /*
		// offset is ratio of left side of rect to full desktop width
		offset_left = IMulDiv32(MAX_MOUSE_RANGE ,wndrect[0], desktoprect[2]);
		out[0]=offset_left +  out[0];


		offset_top = IMulDiv32(MAX_MOUSE_RANGE, wndrect[1],desktoprect[3]);
		out[1]=offset_top + out[1];


	//	out[0] += c->outrect[0];
	//	out[1] += c->outrect[1];
*/

}

/* -------------------------------------------------------------------------- */
long round(long r, long x)
{
    long tempA,tempB,tempC;

    if (r == 0)
        return(x);
    else if (x == 0)
        return(0);
    else if (x < 0)
    {
        tempA=(x/powe(1,r));
        tempB=(x%powe(1,r));
        tempC=powe(1,r);
        tempC=tempC/2;
        return(tempA-(tempB<tempC));

        //		return(r/powe(1,r)) - (r%(powe(1,r))<(-powe(1,r)/2)));//(-0.5*powe(1,r))
    }
    else
    {
        tempA=(x/powe(1,r));
        tempB=(x%powe(1,r));
        tempC=(powe(1,r)/2);
        return(tempA+(tempB>=tempC));
        //		return(1000);//(r/powe(1,r)) + (r%(powe(1,r))>=(powe(1,r)/2)));
    }
    // return(1);
}

/* -------------------------------------------------------------------------- */
long convert(long _nr, long _or, long x)
{
    long ifixconv;

    ifixconv =_nr - _or;
    if (ifixconv >= 0)
        return(x*powe(1,ifixconv));
    else
        return(round(-ifixconv, x));
}

/* -------------------------------------------------------------------------- */
void if4vectormul(int rO, long *vO, int rA, long mA[4][4], int rI, long *vI)
{
    int r;
    int i, j;


    r = rA + rI - rO;

    for (i  = 0; i < 4; i++)
    {
        vO[i] = 0;
        for (j  = 0; j < 4; j++)
        {
            long term;

            term=IMulDiv32(vI[j], mA[i][j],powe(1,r));
            vO[i] += term;
        }
    }
}

/* -------------------------------------------------------------------------- */
void ifhomogenize(int dim, int r, long *v)
{
    int i;

    for (i = 0; i < dim - 1; i++) {
        v[i]=IMulDiv32(v[i],powe(1,r),v[dim - 1]);
    }
    v[dim - 1] = powe(1,r);
}

/* -------------------------------------------------------------------------- */
long IMulDiv32(long aa, long ab, long ac)
{
    long	ia,ib,ic,ret;
    int	sign;


    if (aa == 0)
        return(0);
    if  (ab == 0)
        return(0);
    if (ac == 0)
        return(0);
    if (ac == 1)
        return(aa*ab);
    if (aa == 1)
        return(ab/ac);
    if (ab == 1)
        return(aa/ac);
    if (aa == ac)
        return(ab);
    if (ab == ac)
        return(aa);

    sign  = (aa < 0);
    ia = absol(aa);
    sign ^= (ab < 0);
    ib = absol(ab);
    sign ^= (ac < 0);
    ic = absol(ac);

    ret=scale(ia,ib,ic);

    if (sign == 1)
        ret = -ret;
    return (ret);

}

long powe(long base,int power)
{
    return(base<<power);
}

long absol(long x)
{
    if(x<0)
        return(-x);
    return(x);
}

long scale(long a,long b,long c)
{
    long a_hi,a_lo,b_hi,b_lo,res_hi,res_lo,res_temp;
    int i;

    a_hi=(a&0xffff0000)>>16;
    b_hi=(b&0xffff0000)>>16;
    a_lo=a&0x0000ffff;
    b_lo=b&0x0000ffff;
    res_hi=a_hi*b_hi;
    res_lo=a_lo*b_lo;
    res_temp=a_hi*b_lo;
    res_hi+=(res_temp&0xffff0000)>>16;
    res_lo+=(res_temp&0x0000ffff)<<16;
    res_temp=a_lo*b_hi;
    res_hi+=(res_temp&0xffff0000)>>16;
    res_lo+=(res_temp&0x0000ffff)<<16;

    a=0;
    b=res_hi;
    for(i=0;i<32;i++)
    {
        a<<=1;
	b=(b<<1);//|(res_lo>LONG_MAX?1:0);
	if(res_lo&0x80000000)
            b|=1;
	while(b>=c)
	{
            b-=c;
            a++;
	}
	res_lo<<=1;
    }
    return(a);
}


unsigned char Calibrate(unsigned short XIn, unsigned short YIn,
                        unsigned short *XOut, unsigned short *YOut,
                        CALIB_DATA * Calibration,
                        long max_calib_err,unsigned char calib_error_flag,
                        unsigned char Slate, unsigned char UseKeystone)
{
    long in4[4], out4[4];
    int result;
    long in[2], out[2];
    short clipX = 0, clipY = 0;

    in[0] = XIn;
    in[1] = YIn;


    // clip against bounding box.
    result = Slate;

    if (!result)
    {
        result = bboxclip(Calibration->m_bBox, in);

        if (!result)
        {
            // we're outside the bounding area, but which way ?
            if (in[0] < Calibration->m_bBox[0] || in[0] > Calibration->m_bBox[2])
            {
                int HW = (Calibration->m_bBox[2] - Calibration->m_bBox[0])/2;
                if (in[0] < Calibration->m_bBox[0])
                {
                    clipX = -1;
                    in[0] = Calibration->m_bBox[0] + HW;
                }
                else
                    if (in[0] > Calibration->m_bBox[2])
                    {
                    in[0] = Calibration->m_bBox[2] - HW;
                    clipX = 1;
                }
            }

            if (in[1] < Calibration->m_bBox[1] || in[1] > Calibration->m_bBox[3])
            {
                int HH = (Calibration->m_bBox[3] - Calibration->m_bBox[1])/2;
                if (in[1] < Calibration->m_bBox[1])
                {
                    in[1] = Calibration->m_bBox[1] + HH;
                    clipY = 1;
                }
                else
                    if (in[1] > Calibration->m_bBox[3])
                    {
                    in[1] = Calibration->m_bBox[3] - HH;
                    clipY = -1;
                }
            }

            result = TRUE;
        }
    }

    if (result)
    {
        // within bounding area : expand input point to 3d homogeneous.
        in4[0] = in[0];
        in4[1] = in[1];
        in4[2] = 1;
        in4[3] = 1;

        if (Slate)
        {
            out4[0] = in4[0];
            out4[1] = in4[1];
            out4[2] = in4[2];
            out4[3] = in4[3];
        }
        else
        {
            if4vectormul(Calibration->m_rNorm, out4, Calibration->m_rNorm, Calibration->m_mNorm, 0, in4);
            ifhomogenize(4, Calibration->m_rNorm, out4);

            // clip against cvv.
            result = cvvclip(Calibration->m_rNorm, out4, Calibration->m_accy);
        }

        if (result)
        {
            // convert input points to screen co ordinates
#ifdef _CODE_MECH_
            format(Calibration->m_Outrect,
                   Calibration->m_rOutrect,
                   Calibration->m_rNorm,
                   out4,out);
#else
            formatex(Calibration->m_Outrect,
                     Calibration->m_rOutrect,
                     Calibration->m_rNorm,
                     Calibration->m_wndrect,
                     Calibration->m_wndrect,
                     out4,out,
                     Slate);
#endif
            *XOut = (unsigned short)out[0];
            *YOut = (unsigned short)out[1];




            if (clipX < 0)
            {
                // left edge of desktop
                *XOut = 0;//(USHORT)IMulDiv32(MAX_MOUSE_RANGE ,Calibration->m_wndrect[0], Calibration->m_desktoprect[2]);
            }
            else
                if (clipX > 0)
                {
                // right edge of desktop
                *XOut = MAX_MOUSE_RANGE;//(USHORT)IMulDiv32(MAX_MOUSE_RANGE, Calibration->m_wndrect[2],Calibration->m_desktoprect[2]); // (W * O) / D
            }

            if (clipY < 0)
            {
                //  top edge of desktop
                *YOut = 0;//(USHORT)IMulDiv32(MAX_MOUSE_RANGE ,Calibration->m_wndrect[1], Calibration->m_desktoprect[3]);
            }
            else
                if (clipY > 0)
                {
                // bottom edge of desktop
                *YOut = MAX_MOUSE_RANGE;//(USHORT)IMulDiv32(MAX_MOUSE_RANGE, Calibration->m_wndrect[3],Calibration->m_desktoprect[3]); // (W * O) / D
            }

            // ...and after keystone corrections...
            if ((!Slate) && UseKeystone)
            {
                const long midway = MAX_MOUSE_RANGE / 2;
                const long maxRange = (midway+1)/256;
                unsigned short y,err;
                long index;
                y = *YOut;

                if (y >= midway)
                {
                    y = y - midway;
                    index = scale(y,1,maxRange);
                }
                else
                {
                    index = scale(y,1,maxRange);
                    index = 256 - index;
                }

                if ((index>=0)&&(index<256))
                {
                    y = cosLUT[index];
                    err = (unsigned short)scale(max_calib_err,y,10000);
                }
                else
                    err = 0;

                if (calib_error_flag)
                    *YOut = *YOut + (unsigned short)err;
                else
                    *YOut = *YOut - (unsigned short)err;
            }

            if (UseKeystone)
            {
                // now, we are 0 to MAX_MOUSE_RANGE relative to top left corner of window. Make it relative to the desktop
                *XOut = IMulDiv32(*XOut, Calibration->m_wndrect[2] - Calibration->m_wndrect[0], Calibration->m_desktoprect[2] - Calibration->m_desktoprect[0]);
                *YOut = IMulDiv32(*YOut, Calibration->m_wndrect[3] - Calibration->m_wndrect[1], Calibration->m_desktoprect[3] - Calibration->m_desktoprect[1]);

                // and now add the offset of the window relative to the desktop
                *XOut += IMulDiv32(MAX_MOUSE_RANGE, Calibration->m_wndrect[0], Calibration->m_desktoprect[2]);
                *YOut += IMulDiv32(MAX_MOUSE_RANGE, Calibration->m_wndrect[1], Calibration->m_desktoprect[3]);
            }
        }
        else
        {
            // outside clip : stick with the old values


        }
    } else {
        // outside bounding area : stick with the old values
    }

    return result != FALSE;
}
